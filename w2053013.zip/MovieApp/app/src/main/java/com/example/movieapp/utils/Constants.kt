package com.example.movieapp.utils

object Constants {
    const val BASE_URL = "https://www.omdbapi.com/"
    // Register at OMDb API to get your API key
    const val API_KEY = "d2f21af"
}